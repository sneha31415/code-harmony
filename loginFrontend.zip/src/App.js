
import { LoginPage } from './Components/loginpage/LoginPage';


function App() {
  return (
    <div >
      <LoginPage/>
    </div>
  );
}

// export default App;
// import React from "react";
// import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import { LoginPage } from "./Components/loginpage/LoginPage";
// import { ToastContainer } from "react-toastify"; // Import ToastContainer

// function App() {
//   return (
//     <Router>
//       <Routes>
//         <Route path="/" element={<LoginPage />} />
        
//       </Routes>
//       {/* Add ToastContainer here for global toasts */}
//       <ToastContainer />
//     </Router>
//   );
// }

export default App;


