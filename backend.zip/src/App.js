
import { LoginPage } from './Components/loginpage/LoginPage';


function App() {
  return (
    <div >
      <LoginPage/>
    </div>
  );
}

export default App;
